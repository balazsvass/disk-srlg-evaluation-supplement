#!/bin/sh
# Re-fetch the 24 input files from the public repository of [9], pinned to the
# commit used for the paper, and verify their checksums.
set -e
COMMIT=4e82386d305eee796ee7e19f5c573de0efbbea66
git clone https://github.com/jtapolcai/regional-srlg.git /tmp/regional-srlg
( cd /tmp/regional-srlg && git checkout -q $COMMIT )
mkdir -p data/radius
for R in 50 100 200 500; do mkdir -p data/radius/$R; cp /tmp/regional-srlg/radius/$R/*_srg.lgf data/radius/$R/; done
( cd data && sha256sum -c SHA256SUMS )
