"""run_synth.py N RF SEEDS [--samples S] -- synthetic scaling runs for one (n, r/lmean) group.
Writes ../results/synthetic_raw/n<N>_rf<RF>.csv (overwritten, never appended), so
repeated runs cannot create duplicate seed rows.  Aggregate with make_synthetic_aggregate.py.
--samples sets the random centers per instance in the coverage check (default
50,000, the protocol of the paper)."""
import argparse, csv, os
import numpy as np, srlgproto as sp
ap = argparse.ArgumentParser()
ap.add_argument("n", type=int); ap.add_argument("rf", type=float); ap.add_argument("seeds")
ap.add_argument("--samples", type=int, default=50_000)
args = ap.parse_args()
n, rf, seeds = args.n, args.rf, [int(x) for x in args.seeds.split(',')]
outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "synthetic_raw")
os.makedirs(outdir, exist_ok=True)
rows = []
for seed in seeds:
    g = sp.random_plane_backbone(n, seed); r = rf * g.mean_link()
    res = sp.enumerate_maximal(g, r)
    val = sp.validate_by_sampling(g, res, n_samples=args.samples, seed=seed + 10)
    rows.append({"n": n, "r_over_lmean": rf, "seed": seed, "m": g.m, "x": g.crossings(), "rho": res.rho_r,
                 "K_r": res.K_r, "count": res.count, "memberships": res.memberships,
                 "pairs_covered": res.pairs_covered, "n_rho2": g.n * res.rho_r ** 2,
                 "seconds": round(res.seconds, 2), "uncovered": val["uncovered_labels"],
                 "lemma12": val["lemma12_holds"], "witness_ok": val["witnesses_exact"] and val["pairwise_incomparable"]})
    print(rows[-1])
with open(os.path.join(outdir, f"n{n}_rf{rf}.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
