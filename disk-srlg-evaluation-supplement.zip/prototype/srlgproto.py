"""
srlgproto.py -- reference enumerator for maximal disk-induced SRLGs.

This is the candidate-witness-point prototype used for the proof-of-concept
evaluation in the revised IEEE Access manuscript.  It is NOT the plane-sweep
SinkSweep algorithm; it is an exhaustive, easily checkable implementation of
the characterization behind it:

  * Every maximal disk-induced SRLG S has a nonempty convex witness region
    W(S) = intersection of the closed hippodromes N(e,r), e in S.  Under
    general position, W(S) is the closure of a sink face of the arrangement,
    so it has a vertex at an intersection of two hippodrome boundaries, or
    (for a singleton) is one full hippodrome.
  * Therefore the label S(p) of some candidate point p -- an intersection of
    two primitive curves (offset lines / endpoint circles) of two interacting
    links, or a point of a single hippodrome -- equals S.  Over-generous
    candidate sets are harmless: every candidate label is a true label of a
    real point, so inclusion-maximal filtering returns exactly R_r.

Everything is vectorized with NumPy.  Distances are closed (<= r), matching
the closed-disk model of the manuscript, with a fixed relative tolerance to
absorb floating-point error at the generating intersection points.  This is
a floating-point prototype: coordinates are centered before any computation
and the tolerance is 1e-9 times the centered extent, so results are
translation-invariant, but no exactness is claimed for inputs that are
degenerate at that scale.  The agreement with the archived lists of [9] is
a finite-instance check, not a proof of exact enumeration.

The module measures K_r (interacting pairs), |R_r|, the explicit output
size sum |S|, and checks the inequality of Lemma 12.  It does NOT construct
the arrangement of hippodrome boundaries, so it reports no arrangement
size.  Protected-terminal enumeration is not included: a boundary-only
candidate construction does not by itself certify strict avoidance of the
closed protective disks (Section VI of the manuscript).
"""
from __future__ import annotations

import itertools
import math
import re
import time
from dataclasses import dataclass, field

import numpy as np

# ----------------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------------

def point_segment_dist(P: np.ndarray, A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Distances from points P (N x 2) to segments A->B (M x 2 each): N x M."""
    AB = B - A                                    # M x 2
    L2 = np.einsum("ij,ij->j", AB.T, AB.T)        # M
    L2 = np.where(L2 > 0, L2, 1.0)
    AP = P[:, None, :] - A[None, :, :]            # N x M x 2
    t = np.einsum("nmk,mk->nm", AP, AB) / L2[None, :]
    t = np.clip(t, 0.0, 1.0)
    C = A[None, :, :] + t[:, :, None] * AB[None, :, :]
    D = P[:, None, :] - C
    return np.sqrt(np.einsum("nmk,nmk->nm", D, D))


def seg_seg_dist(A1, B1, A2, B2) -> float:
    """Exact distance between two segments (floating point)."""
    if segments_cross(A1, B1, A2, B2):
        return 0.0
    P = np.array([A1, B1, A2, B2])
    d1 = point_segment_dist(P[:2], np.array([A2]), np.array([B2])).min()
    d2 = point_segment_dist(P[2:], np.array([A1]), np.array([B1])).min()
    return float(min(d1, d2))


def orient(a, b, c) -> float:
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def on_segment_interior(a, b, p, eps=1e-9) -> bool:
    if abs(orient(a, b, p)) > eps:
        return False
    return (min(a[0], b[0]) - eps <= p[0] <= max(a[0], b[0]) + eps and
            min(a[1], b[1]) - eps <= p[1] <= max(a[1], b[1]) + eps)


def segments_cross(a1, b1, a2, b2) -> bool:
    """True iff the RELATIVE INTERIORS of the two closed segments intersect:
    a proper crossing, or a collinear overlap of positive length.  Shared
    endpoints and T-contacts (an endpoint of one segment lying on the other)
    are NOT crossings, matching the definition of x in the manuscript."""
    o1, o2 = orient(a1, b1, a2), orient(a1, b1, b2)
    o3, o4 = orient(a2, b2, a1), orient(a2, b2, b1)
    eps = 1e-12 * max(1.0, abs(o1), abs(o2), abs(o3), abs(o4))
    if (o1 * o2 < -eps * eps) and (o3 * o4 < -eps * eps):
        return True                                   # proper crossing
    if max(abs(o1), abs(o2), abs(o3), abs(o4)) > eps:
        return False                                  # not collinear, no proper crossing
    # collinear: positive-length overlap of the parameter intervals
    d = b1 - a1
    dd = float(np.dot(d, d))
    if dd == 0.0:
        return False
    t2 = sorted([float(np.dot(a2 - a1, d) / dd), float(np.dot(b2 - a1, d) / dd)])
    lo, hi = max(0.0, t2[0]), min(1.0, t2[1])
    return hi - lo > 1e-12


def line_line(p1, n1, c1, p2, n2, c2):
    """Intersection of lines n1.x = c1 and n2.x = c2 (n unit normals)."""
    det = n1[0] * n2[1] - n1[1] * n2[0]
    if abs(det) < 1e-12:
        return []
    x = (c1 * n2[1] - c2 * n1[1]) / det
    y = (n1[0] * c2 - n2[0] * c1) / det
    return [(x, y)]


def line_circle(n, c, center, r):
    """Intersections of line n.x = c with circle |x-center| = r."""
    d = c - np.dot(n, center)
    if abs(d) > r + 1e-12:
        return []
    h2 = r * r - d * d
    h = math.sqrt(max(h2, 0.0))
    base = center + d * n
    t = np.array([-n[1], n[0]])
    return [tuple(base + h * t), tuple(base - h * t)]


def circle_circle(c1, r1, c2, r2):
    dvec = c2 - c1
    d = float(np.hypot(*dvec))
    if d < 1e-12 or d > r1 + r2 + 1e-12 or d < abs(r1 - r2) - 1e-12:
        return []
    a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    h = math.sqrt(max(r1 * r1 - a * a, 0.0))
    mid = c1 + a * dvec / d
    perp = np.array([-dvec[1], dvec[0]]) / d
    return [tuple(mid + h * perp), tuple(mid - h * perp)]


# ----------------------------------------------------------------------------
# Graph container
# ----------------------------------------------------------------------------

@dataclass
class GeomGraph:
    name: str
    xy: np.ndarray                 # n x 2 node coordinates
    edges: list                    # list of (u, v) node indices
    labels: list = field(default_factory=list)   # original edge labels (optional)

    @property
    def n(self):
        return len(self.xy)

    @property
    def m(self):
        return len(self.edges)

    def seg_arrays(self):
        A = np.array([self.xy[u] for u, v in self.edges], dtype=float)
        B = np.array([self.xy[v] for u, v in self.edges], dtype=float)
        return A, B

    def crossings(self) -> int:
        A, B = self.seg_arrays()
        x = 0
        for i in range(self.m):
            for j in range(i + 1, self.m):
                if segments_cross(A[i], B[i], A[j], B[j]):
                    x += 1
        return x

    def shortest_link(self) -> float:
        A, B = self.seg_arrays()
        return float(np.min(np.hypot(*(B - A).T)))

    def mean_link(self) -> float:
        A, B = self.seg_arrays()
        return float(np.mean(np.hypot(*(B - A).T)))


def read_lgf(path: str, name: str | None = None):
    """Read a LEMON .lgf file with @nodes (label, coords) and @edges, and an
    optional @srlgs section listing edge labels per SRLG.  Returns
    (GeomGraph, list_of_srlgs_as_frozensets_of_edge_indices)."""
    nodes, edges, srlgs = {}, [], []
    section = None
    label_to_idx = {}
    with open(path) as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            if line.startswith("@"):
                section = line[1:].strip()
                header_skipped = False
                continue
            if section == "nodes":
                if line.startswith("label"):
                    continue
                parts = line.split()
                lab = parts[0]
                mm = re.match(r"\(([-0-9.]+),([-0-9.]+)\)", parts[1])
                nodes[lab] = (float(mm.group(1)), float(mm.group(2)))
            elif section == "edges":
                if line.startswith("label"):
                    continue
                parts = line.split()
                if len(parts) < 3:
                    continue
                u, v, lab = parts[0], parts[1], parts[2]
                label_to_idx[lab] = len(edges)
                edges.append((u, v, lab))
            elif section == "srlgs":
                srlgs.append(frozenset(label_to_idx[t] for t in line.split()))
    node_ids = sorted(nodes, key=lambda s: int(s))
    idx = {lab: i for i, lab in enumerate(node_ids)}
    xy = np.array([nodes[lab] for lab in node_ids], dtype=float)
    g = GeomGraph(name or path, xy, [(idx[u], idx[v]) for u, v, _ in edges],
                  [lab for _, _, lab in edges])
    return g, srlgs


# ----------------------------------------------------------------------------
# Enumeration
# ----------------------------------------------------------------------------

@dataclass
class EnumResult:
    r: float
    maximal: list                 # list of frozensets of edge indices
    witnesses: list               # one witness point per maximal set
    K_r: int                      # interacting pairs (d(e,f) <= 2r)
    rho_r: int
    n_candidates: int
    seconds: float

    @property
    def count(self):
        return len(self.maximal)

    @property
    def memberships(self):
        return sum(len(S) for S in self.maximal)

    @property
    def pairs_covered(self):
        return sum(len(S) * (len(S) - 1) // 2 for S in self.maximal)


def _primitives(A, B, r):
    """Primitive curves of each hippodrome: 2 offset lines (unit normal n,
    offset c, as n.x = c) and 2 circles (center, r)."""
    prims = []
    for a, b in zip(A, B):
        d = b - a
        L = float(np.hypot(*d))
        u = d / L
        nrm = np.array([-u[1], u[0]])
        lines = [(nrm, float(np.dot(nrm, a)) + r), (nrm, float(np.dot(nrm, a)) - r)]
        circles = [(a, r), (b, r)]
        junctions = [a + r * nrm, a - r * nrm, b + r * nrm, b - r * nrm,
                     a - r * u, b + r * u, (a + b) / 2, a, b]
        prims.append((lines, circles, junctions))
    return prims


def _pair_candidates(pe, pf):
    pts = []
    lines_e, circles_e, _ = pe
    lines_f, circles_f, _ = pf
    for (n1, c1) in lines_e:
        for (n2, c2) in lines_f:
            pts += line_line(None, n1, c1, None, n2, c2)
        for (ctr, rr) in circles_f:
            pts += line_circle(n1, c1, ctr, rr)
    for (ctr, rr) in circles_e:
        for (n2, c2) in lines_f:
            pts += line_circle(n2, c2, ctr, rr)
        for (ctr2, rr2) in circles_f:
            pts += circle_circle(ctr, rr, ctr2, rr2)
    return pts


def labels_at(P, A, B, r, tol):
    """Boolean N x M matrix: link j hit by the closed radius-r disk at P_i."""
    D = point_segment_dist(P, A, B)
    return D <= r + tol


def _maximal_from_masks(masks: list[int]):
    """Inclusion-maximal members of a list of bitmask labels."""
    uniq = sorted(set(masks), key=lambda t: -bin(t).count("1"))
    maximal = []
    for L in uniq:
        if L == 0:
            continue
        if any((L & ~M) == 0 for M in maximal):
            continue
        maximal.append(L)
    return maximal


def _mask_to_set(mask: int) -> frozenset:
    return frozenset(i for i in range(mask.bit_length()) if (mask >> i) & 1)


def interacting_pairs(A, B, r):
    """All unordered pairs {e,f} with d(e,f) <= 2r.  Vectorized: for
    non-crossing segments the distance is attained at an endpoint of one of
    them; crossing pairs (distance 0) are detected separately among pairs
    whose bounding boxes overlap."""
    m = len(A)
    P = np.concatenate([A, B])                      # 2m endpoints
    D = point_segment_dist(P, A, B)                 # 2m x m
    Dend = np.minimum(D[:m], D[m:])                 # Dend[e, f] = min over endpoints of e
    Dsym = np.minimum(Dend, Dend.T)
    iu = np.triu_indices(m, 1)
    close = Dsym[iu] <= 2 * r + 1e-9
    # bounding-box overlap test for potential crossings among far pairs
    lo = np.minimum(A, B); hi = np.maximum(A, B)
    ov = ((lo[:, None, 0] <= hi[None, :, 0]) & (lo[None, :, 0] <= hi[:, None, 0]) &
          (lo[:, None, 1] <= hi[None, :, 1]) & (lo[None, :, 1] <= hi[:, None, 1]))
    cand_cross = ov[iu] & ~close
    pairs = [(int(i), int(j)) for i, j in zip(iu[0][close], iu[1][close])]
    for i, j in zip(iu[0][cand_cross], iu[1][cand_cross]):
        if segments_cross(A[i], B[i], A[j], B[j]):
            pairs.append((int(i), int(j)))
    pairs.sort()
    return pairs


def _center(g: GeomGraph):
    """Center coordinates at the node centroid (translation invariance)."""
    off = g.xy.mean(axis=0)
    A, B = g.seg_arrays()
    A = A - off
    B = B - off
    return A, B, off


def _tolerance(A, B, r):
    return 1e-9 * max(float(np.max(np.abs(np.concatenate([A, B])))) + r, 1.0)


def enumerate_maximal(g: GeomGraph, r: float, tol: float | None = None) -> EnumResult:
    """Enumerate R_r, the inclusion-maximal link sets hit by one closed disk
    of radius r.  The closed label S(p) of every candidate point is a label
    of a real placement, so inclusion-maximal filtering returns the maximal
    disk-induced SRLGs (up to the floating-point tolerance)."""
    t0 = time.perf_counter()
    A, B, off = _center(g)
    m = g.m
    if tol is None:
        tol = _tolerance(A, B, r)
    prims = _primitives(A, B, r)
    pairs = interacting_pairs(A, B, r)

    # ---- candidate points
    cand = []
    for (lines, circles, junctions) in prims:
        cand += [tuple(p) for p in junctions]
    for (i, j) in pairs:
        cand += _pair_candidates(prims[i], prims[j])

    P = np.array(cand, dtype=float).reshape(-1, 2)
    P = np.unique(np.round(P, 9), axis=0)

    # ---- labels (chunked)
    masks = []
    CH = 4096
    for s0 in range(0, len(P), CH):
        Q = P[s0:s0 + CH]
        D = point_segment_dist(Q, A, B)
        H = D <= r + tol
        for row in H:
            mk = 0
            for idx in np.flatnonzero(row):
                mk |= (1 << int(idx))
            masks.append(mk)

    maximal_masks = _maximal_from_masks(masks)
    maximal = [_mask_to_set(mk) for mk in maximal_masks]
    first = {}
    for p, mk in zip(P, masks):
        if mk in maximal_masks and mk not in first:
            first[mk] = tuple(p + off)        # back to original coordinates
    witnesses = [first[mk] for mk in maximal_masks]
    rho = max((len(S) for S in maximal), default=0)
    return EnumResult(r, maximal, witnesses, len(pairs), rho, len(P),
                      time.perf_counter() - t0)


# ----------------------------------------------------------------------------
# Validation
# ----------------------------------------------------------------------------

def validate_by_sampling(g: GeomGraph, res: EnumResult, n_samples=200_000,
                         seed=0, tol=None) -> dict:
    """Independent checks of an enumeration result:
      * every stored witness realizes its set exactly;
      * the listed sets are pairwise incomparable;
      * the labels of n_samples random disk centers are all contained in a
        listed set;
      * the inequality K_r <= sum binom(|S|,2) of Lemma 12.
    The sampling check is evidence of completeness, not a proof: a maximal
    set whose exact-label region is tiny may be missed by the samples."""
    rng = np.random.default_rng(seed)
    A, B, off = _center(g)
    r = res.r
    if tol is None:
        tol = _tolerance(A, B, r)
    lo = np.min(np.concatenate([A, B]), axis=0) - r
    hi = np.max(np.concatenate([A, B]), axis=0) + r
    masks_max = [sum(1 << i for i in S) for S in res.maximal]
    bad = 0
    nonempty = 0
    done = 0
    while done < n_samples:
        k = min(20000, n_samples - done)
        Q = rng.uniform(lo, hi, size=(k, 2))
        H = labels_at(Q, A, B, r, tol)
        for row in H:
            idx = np.flatnonzero(row)
            if len(idx) == 0:
                continue
            nonempty += 1
            mk = 0
            for i in idx:
                mk |= (1 << int(i))
            if not any((mk & ~M) == 0 for M in masks_max):
                bad += 1
        done += k
    # witness check: exact label
    W = np.array(res.witnesses, dtype=float).reshape(-1, 2) - off
    wit_ok = True
    if len(W):
        H = labels_at(W, A, B, r, tol)
        for row, S in zip(H, res.maximal):
            if frozenset(np.flatnonzero(row).tolist()) != S:
                wit_ok = False
    incomparable = all(not (S < T) for S in res.maximal for T in res.maximal)
    return {"samples": n_samples, "nonempty_labels": nonempty,
            "uncovered_labels": bad, "witnesses_exact": wit_ok,
            "pairwise_incomparable": incomparable,
            "lemma12_holds": res.K_r <= res.pairs_covered}


# ----------------------------------------------------------------------------
# Instance generators
# ----------------------------------------------------------------------------

def lower_bound_instance(q: int) -> GeomGraph:
    """The construction of Proposition 14 (from [9, Claim 1]): 4q axis-parallel
    unit-spaced links of length q around the square [0,q]^2; radius q gives
    exactly (q+1)^2 maximal sets of size 2q."""
    xy, edges = [], []
    for h in range(1, q + 1):
        for (p1, p2) in [((0, -h), (q, -h)), ((0, q + h), (q, q + h)),
                         ((-h, 0), (-h, q)), ((q + h, 0), (q + h, q))]:
            xy += [p1, p2]
            edges.append((len(xy) - 2, len(xy) - 1))
    return GeomGraph(f"lb_q{q}", np.array(xy, dtype=float), edges)


def random_plane_backbone(n: int, seed: int, avg_degree: float = 3.2) -> GeomGraph:
    """Random points in a 1000 x 1000 square, Delaunay triangulation, keep a
    Euclidean minimum spanning tree plus random Delaunay edges until the
    average degree is reached.  Plane by construction."""
    from scipy.spatial import Delaunay
    rng = np.random.default_rng(seed)
    xy = rng.uniform(0, 1000, size=(n, 2))
    tri = Delaunay(xy)
    E = set()
    for simplex in tri.simplices:
        for a, b in itertools.combinations(sorted(simplex.tolist()), 2):
            E.add((a, b))
    E = sorted(E, key=lambda e: float(np.hypot(*(xy[e[0]] - xy[e[1]]))))
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    chosen, rest = [], []
    for (a, b) in E:
        if find(a) != find(b):
            parent[find(a)] = find(b)
            chosen.append((a, b))
        else:
            rest.append((a, b))
    target = int(round(avg_degree * n / 2))
    rng.shuffle(rest)
    chosen += rest[:max(0, target - len(chosen))]
    return GeomGraph(f"rnd_n{n}_s{seed}", xy, chosen)
