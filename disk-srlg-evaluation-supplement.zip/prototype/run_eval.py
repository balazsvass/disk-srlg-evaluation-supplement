"""run_eval.py -- real-network and lower-bound measurements.

Usage:  python3 run_eval.py [--samples N] [DATA_DIR]      (default: ../data)

Outputs (in ../results):
  real_networks.csv   one row per (network, radius): K_r, |R_r|, sum|S|, validation
  lowerbound.csv      the explicit-output lower-bound family of Prop. 14
  summary.json        validation flags and software versions

--samples sets the number of random disk centers per instance in the
coverage check (default 200,000, the protocol of the paper; use a smaller
value for a quick run).
"""
import argparse, csv, json, os, platform
import numpy as np, scipy
import srlgproto as sp

HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument("--samples", type=int, default=200_000)
ap.add_argument("data_dir", nargs="?", default=os.path.join(HERE, "..", "data"))
args = ap.parse_args()
DATA = args.data_dir
OUT = os.path.join(HERE, "..", "results")
os.makedirs(OUT, exist_ok=True)
NETS = [("16_optic_pan_eu_scaled", "Pan-EU"), ("22_optic_eu_scaled", "EU-22"),
        ("24_us_wide_scaled", "US-24"), ("28_optic_eu_scaled", "EU-28"),
        ("39_optic_north_american_scaled", "NA-39"), ("79_optic_nfsnet_scaled", "NFSNet-79")]
RADII = [50, 100, 200, 500]
summary = {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
           "machine": platform.machine(), "timing_protocol": "single run, wall clock, enumerate_maximal only (no validation)",
           "samples_per_instance": args.samples,
           "all_archived_lists_equal": True, "all_sampling_ok": True, "all_lemma12_ok": True,
           "all_witness_ok": True, "lowerbound_ok": True}

# ---------------------------------------------------------------- lower bound
rows = []
for q in range(1, 11):
    g = sp.lower_bound_instance(q)
    res = sp.enumerate_maximal(g, float(q))
    ok = res.count == (q + 1) ** 2 and all(len(S) == 2 * q for S in res.maximal)
    summary["lowerbound_ok"] &= ok
    rows.append({"q": q, "n": g.n, "m": g.m, "rho": res.rho_r, "count": res.count,
                 "expected": (q + 1) ** 2, "memberships": res.memberships, "n_rho2": g.n * res.rho_r ** 2, "ok": ok})
with open(f"{OUT}/lowerbound.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print("lower bound family ok:", summary["lowerbound_ok"])

# ---------------------------------------------------------------- real networks
rows = []
for net, short in NETS:
    for R in RADII:
        g, arch = sp.read_lgf(f"{DATA}/radius/{R}/{net}_srg.lgf", short)
        x = g.crossings()
        res = sp.enumerate_maximal(g, float(R))
        val = sp.validate_by_sampling(g, res, n_samples=args.samples, seed=1)
        arch_max = {S for S in arch if not any(S < T for T in arch)}
        equal = set(res.maximal) == arch_max
        summary["all_archived_lists_equal"] &= equal
        summary["all_sampling_ok"] &= (val["uncovered_labels"] == 0)
        summary["all_lemma12_ok"] &= bool(val["lemma12_holds"])
        summary["all_witness_ok"] &= bool(val["witnesses_exact"]) and bool(val["pairwise_incomparable"])
        row = {"network": short, "n": g.n, "m": g.m, "x": x, "r_km": R,
               "lmin_km": round(g.shortest_link(), 1), "lmean_km": round(g.mean_link(), 1),
               "rho": res.rho_r, "K_r": res.K_r, "count": res.count, "memberships": res.memberships,
               "pairs_covered": res.pairs_covered, "n_rho2": g.n * res.rho_r ** 2,
               "archived_count": len(arch), "archived_maximal": len(arch_max), "equal_to_archive": equal,
               "uncovered_sampled_labels": val["uncovered_labels"], "witnesses_exact": val["witnesses_exact"],
               "lemma12_holds": val["lemma12_holds"], "seconds": round(res.seconds, 2)}
        rows.append(row)
        print({k: row[k] for k in ["network", "r_km", "rho", "K_r", "count", "memberships", "equal_to_archive", "uncovered_sampled_labels"]})
with open(f"{OUT}/real_networks.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
with open(f"{OUT}/summary.json", "w") as fh:
    json.dump(summary, fh, indent=1)
print(json.dumps(summary, indent=1))
