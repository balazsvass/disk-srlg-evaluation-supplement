# Evaluation data

These are the retained measurements behind Table 4 and Figure 5. The reported values are retained from the reference experiment. All 84 case counts (24 backbone, 10 lower-bound, 50 synthetic) were reproduced again with the disk prototype in `prototype/` for the revised manuscript.

- `real_networks.csv`: 24 network/radius cases. For the revised manuscript, the unprotected prototype was rerun on all 24 archived inputs; the retained counts and complete maximal families agreed. The inputs are the files `radius/{50,100,200,500}/*_srg.lgf` of [jtapolcai/regional-srlg](https://github.com/jtapolcai/regional-srlg); vendored copies, checksums, and a pinned fetch script are in `data/` and `fetch_data.sh`. `scripts/check_archive.py` recomputes the columns n, m, rho, K_r, sinks, and memberships of this file from those inputs alone.
- The last column of Table 4, $\lVert\mathcal R_r\rVert+3m$, is derived from `memberships` and `m`; it is not a separate measurement.
- `lowerbound.csv`: the ten construction cases of the explicit-output lower bound (Proposition 14), also rerun for the revised manuscript.
- `synthetic_raw.csv`: the 50 per-seed measurements used in the previous evaluation and reproduced in the earlier audit. All 50 synthetic cases were rerun with the prototype for the revised manuscript and their retained counts were reproduced. Its curation checks used 1,000 random centers per case; this is separate from the original 50,000-center validation protocol, which remains available through the driver defaults.

Only the columns used or checked in this revision are retained. Arrangement-face counts and protected-terminal measurements are omitted because they were not certified by the available prototype.

Run `python3 scripts/generate_evaluation.py` from the repository root to regenerate the table and plot (written to `fig/`). The script uses only the Python standard library. Each plotted point is the arithmetic mean of five per-instance normalized measurements; error bars are sample standard deviations, with divisor four. In particular, the bottom panel averages individual membership ratios, rather than dividing the mean membership count by the mean normalization denominator. This explains its small differences from the previous plot.

This directory contains measurement records; the reporting script is `scripts/generate_evaluation.py`. The unprotected prototype and its reproduction driver are in `prototype/`, the benchmark inputs in `data/`. Numerical witness checks used the prototype's distance tolerances; they are not certificates of exact predicates on arbitrary degenerate inputs. The paper's exact algorithms and the floating-point reference experiment are explicitly distinguished.
