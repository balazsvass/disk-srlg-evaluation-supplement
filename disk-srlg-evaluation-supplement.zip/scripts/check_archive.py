#!/usr/bin/env python3
"""Recompute the archive-derived columns of Table 4 from the 24 public inputs.

For every network/radius case in evaluation-data/real_networks.csv this script
parses data/radius/<r>/<network>_srg.lgf and
recomputes, independently of the prototype,
  n, m                 from the @nodes and @edges sections,
  |R_r| and ||R_r||    the number of archived maximal SRLGs and their total
                       memberships (the paper's computed family equals the
                       archived family, so these are the Table 4 values),
  rho_r                the largest archived SRLG (a maximal set realizes the
                       largest number of links one disk can hit),
  K_r                  the number of link pairs at Euclidean distance <= 2r,
and compares them with the retained measurements. Coordinates are in km.
Only the Python standard library is needed.
"""
import csv
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {'Pan-EU': '16_optic_pan_eu_scaled_srg.lgf', 'EU-22': '22_optic_eu_scaled_srg.lgf',
         'US-24': '24_us_wide_scaled_srg.lgf', 'EU-28': '28_optic_eu_scaled_srg.lgf',
         'NA-39': '39_optic_north_american_scaled_srg.lgf', 'NFSNet-79': '79_optic_nfsnet_scaled_srg.lgf'}


def parse_lgf(path):
    nodes, edges, srlgs, section = {}, [], [], None
    for line in path.read_text().splitlines():
        line = line.rstrip()
        if not line.strip():
            continue
        if line.startswith('@'):
            section, header = line.strip(), True
            continue
        if section in ('@nodes', '@edges') and header:
            header = False
            continue
        parts = line.split('\t')
        if section == '@nodes':
            x, y = parts[1].strip('()').split(',')
            nodes[parts[0]] = (float(x), float(y))
        elif section == '@edges':
            edges.append((parts[0], parts[1], int(parts[2])))
        elif section == '@srlgs':
            srlgs.append(sorted(int(t) for t in line.split()))
    return nodes, edges, srlgs


def seg_dist(p, q, u, v):
    """Euclidean distance between segments pq and uv."""
    def orient(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])
    def on_seg(a, b, c):
        return min(a[0], b[0]) <= c[0] <= max(a[0], b[0]) and min(a[1], b[1]) <= c[1] <= max(a[1], b[1])
    o1, o2, o3, o4 = orient(p, q, u), orient(p, q, v), orient(u, v, p), orient(u, v, q)
    if o1*o2 < 0 and o3*o4 < 0:  # proper crossing
        return 0.0
    if (o1 == 0 and on_seg(p, q, u)) or (o2 == 0 and on_seg(p, q, v)) or \
       (o3 == 0 and on_seg(u, v, p)) or (o4 == 0 and on_seg(u, v, q)):
        return 0.0
    def pt_seg(c, a, b):
        dx, dy = b[0]-a[0], b[1]-a[1]
        t = 0.0 if dx == dy == 0 else max(0.0, min(1.0, ((c[0]-a[0])*dx + (c[1]-a[1])*dy)/(dx*dx+dy*dy)))
        return math.hypot(c[0]-a[0]-t*dx, c[1]-a[1]-t*dy)
    return min(pt_seg(u, p, q), pt_seg(v, p, q), pt_seg(p, u, v), pt_seg(q, u, v))


def main():
    rows = list(csv.DictReader((ROOT/'evaluation-data'/'real_networks.csv').open(newline='')))
    failures = 0
    print(f"{'network':10s} {'r':>4s} {'n':>3s} {'m':>4s} {'rho':>4s} {'K_r':>5s} {'|R|':>4s} {'||R||':>6s}  status")
    for row in rows:
        path = ROOT/'data'/'radius'/row['r_km']/FILES[row['network']]
        if not path.exists():
            print(f"{row['network']:10s} {row['r_km']:>4s}  missing input {path.relative_to(ROOT)} (run fetch_data.sh)")
            failures += 1
            continue
        nodes, edges, srlgs = parse_lgf(path)
        r = float(row['r_km'])
        segs = [(nodes[a], nodes[b]) for a, b, _ in edges]
        k_r = sum(1 for i in range(len(segs)) for j in range(i+1, len(segs))
                  if seg_dist(*segs[i], *segs[j]) <= 2*r + 1e-9)
        got = dict(n=len(nodes), m=len(edges), rho=max(len(s) for s in srlgs), K_r=k_r,
                   sinks=len(srlgs), memberships=sum(len(s) for s in srlgs))
        exp = {k: int(row[k]) for k in got}
        ok = got == exp
        failures += not ok
        print(f"{row['network']:10s} {row['r_km']:>4s} {got['n']:3d} {got['m']:4d} {got['rho']:4d} {got['K_r']:5d} "
              f"{got['sinks']:4d} {got['memberships']:6d}  {'ok' if ok else 'MISMATCH ' + str({k: (got[k], exp[k]) for k in got if got[k] != exp[k]})}")
    print('all 24 cases agree with evaluation-data/real_networks.csv' if not failures else f'{failures} case(s) differ')
    sys.exit(1 if failures else 0)


if __name__ == '__main__':
    main()
