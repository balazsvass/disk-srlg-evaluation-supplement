#!/usr/bin/env python3
"""Export the retained measurement files from the prototype's results.

Reads results/real_networks.csv, results/lowerbound.csv and
results/synthetic_raw/*.csv (written by prototype/run_eval.py and
prototype/run_synth.py) and writes the column subsets that the manuscript's
Table 4 and Figure 5 are generated from:

  evaluation-data/real_networks.csv   network,n,m,x,r_km,rho,K_r,sinks,memberships,pairs_covered,archived_maximal
  evaluation-data/lowerbound.csv      q,n,m,rho,count,memberships,n_rho2
  evaluation-data/synthetic_raw.csv   n,r_over_lmean,seed,m,rho,K_r,sinks,memberships,pairs_covered,n_rho2

("sinks" is the prototype's "count": the number of inclusion-maximal sets,
i.e. of sink faces.)  With --check, the files are not written; instead the
exported rows are compared with the retained files and any difference is
reported.  Timings and validation flags stay in results/.
"""
import argparse
import csv
import glob
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = {
    'real_networks.csv': (['network', 'n', 'm', 'x', 'r_km', 'rho', 'K_r', 'sinks', 'memberships', 'pairs_covered', 'archived_maximal'], None),
    'lowerbound.csv': (['q', 'n', 'm', 'rho', 'count', 'memberships', 'n_rho2'], None),
    'synthetic_raw.csv': (['n', 'r_over_lmean', 'seed', 'm', 'rho', 'K_r', 'sinks', 'memberships', 'pairs_covered', 'n_rho2'], None),
}


def load_results():
    out = {}
    out['real_networks.csv'] = list(csv.DictReader((ROOT / 'results' / 'real_networks.csv').open(newline='')))
    out['lowerbound.csv'] = list(csv.DictReader((ROOT / 'results' / 'lowerbound.csv').open(newline='')))
    rows = []
    for f in sorted(glob.glob(str(ROOT / 'results' / 'synthetic_raw' / '*.csv'))):
        rows += list(csv.DictReader(open(f, newline='')))
    rows.sort(key=lambda r: (int(r['n']), float(r['r_over_lmean']), int(r['seed'])))
    out['synthetic_raw.csv'] = rows
    return out


def export_rows(name, rows):
    cols = SPEC[name][0]
    res = []
    for r in rows:
        r = dict(r)
        if 'count' in r and 'sinks' in cols:
            r['sinks'] = r['count']
        res.append({c: r[c] for c in cols})
    return res


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check', action='store_true', help='compare with the retained files instead of writing them')
    args = ap.parse_args()
    results = load_results()
    bad = 0
    for name, rows in results.items():
        exported = export_rows(name, rows)
        target = ROOT / 'evaluation-data' / name
        if args.check:
            retained = list(csv.DictReader(target.open(newline='')))
            same = [{k: r[k] for k in SPEC[name][0]} for r in retained] == exported
            print(f"{name}: {len(exported)} rows, {'identical to retained file' if same else 'DIFFERS from retained file'}")
            bad += not same
        else:
            with target.open('w', newline='') as fh:
                w = csv.DictWriter(fh, fieldnames=SPEC[name][0], lineterminator='\r\n')
                w.writeheader(); w.writerows(exported)
            print(f"wrote {target.relative_to(ROOT)} ({len(exported)} rows)")
    sys.exit(1 if bad else 0)


if __name__ == '__main__':
    main()
