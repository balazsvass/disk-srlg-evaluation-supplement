#!/usr/bin/env python3
"""Regenerate the paper's evaluation figures/tables and the response excerpt.

Uses retained measurements, not new simulations. Only the Python standard
library is needed. Error bars are sample standard deviations (ddof=1) of the
five per-seed normalized measurements; points are their arithmetic means.
"""
import argparse
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    with (ROOT / 'evaluation-data' / name).open(newline='') as f:
        return list(csv.DictReader(f))


def backbone_table(rows):
    out = [r'\begin{table*}[t]', r'\centering\small',
        r'\caption{Measured quantities on the six backbone networks of \cite{tapolcai2020fast} (coordinates in km from its public archive; all plane, $x=0$). $K_r$ counts interacting link pairs, $|\M_r|$ counts maximal SRLGs, and $\Rrsum=\sum_{S\in\M_r}|S|$ is the explicit output size. In all 24 cases the computed maximal family coincides with the archived maximal family. The ratio $\Rrsum/(n\rho_r^2)$ normalizes the output size by its worst-case order; it is not a running-time ratio. The last column is the size of the routing list without terminal protection up to the terminal deduction: for terminals $s,t$, the list $\M_r\cup\mathcal R_{\mathrm{elem}}$ of \cref{lem:elementary} has $\Rrsum+3m-\deg s-\deg t$ memberships.}',
        r'\label{tab:eval}', r'\begin{tabular*}{0.8\textwidth}{@{\extracolsep{\fill}}lrrrrrrrrr@{}}', r'\toprule',
        r'network & $n$ & $m$ & $r$ [km] & $\rho_r$ & $K_r$ & $|\M_r|$ & $\Rrsum$ & $\Rrsum/(n\rho_r^2)$ & $\Rrsum+3m$\\', r'\midrule']
    previous = None
    for row in rows:
        name = row['network']
        first = name != previous
        if previous is not None and first:
            out.append(r'\addlinespace[2pt]')
        n, m, rho, mem = int(row['n']), int(row['m']), int(row['rho']), int(row['memberships'])
        out.append(' & '.join([name if first else '', row['n'] if first else '', row['m'] if first else '',
            row['r_km'], row['rho'], row['K_r'], row['sinks'], row['memberships'],
            f'{mem/(n*rho*rho):.3f}', str(mem+3*m)]) + r'\\')
        previous = name
    out.extend([r'\bottomrule', r'\end{tabular*}', r'\end{table*}'])
    return '\n'.join(out)+'\n'


def response_table(rows):
    out = [r'\begin{center}', r'\begin{minipage}{\linewidth}\centering\small', r'\begin{tabular}{@{}lrrrrrrr@{}}', r'\toprule',
        r'network & $n$ & $m$ & $\rho_r$ & $K_r$ & $|\mathcal R_r|$ & $\Rrsum$ & $\Rrsum+3m$\\', r'\midrule']
    for row in rows:
        if int(row['r_km']) == 500:
            out.append(' & '.join([row[k] for k in ['network','n','m','rho','K_r','sinks','memberships']]
                                  + [str(int(row['memberships'])+3*int(row['m']))])+r'\\')
    out.extend([r'\bottomrule', r'\end{tabular}', r'\par\smallskip',
        r'\footnotesize Extract from manuscript Table~4: disaster radius $r=500$~km; $\Rrsum+3m$ is the unprotected routing-list size up to the terminal deduction $\deg s+\deg t$.', r'\end{minipage}', r'\end{center}'])
    return '\n'.join(out)+'\n'


def scaling_figure(raw):
    groups = defaultdict(list)
    seen = set()
    for row in raw:
        n, rf, seed = int(row['n']), float(row['r_over_lmean']), int(row['seed'])
        key = n, rf, seed
        if key in seen:
            raise ValueError(f'Duplicate synthetic run: {key}')
        seen.add(key)
        groups[n,rf].append(row)
    assert len(groups) == 10 and all(len(v) == 5 for v in groups.values())
    ns = [50,100,200,400,800]
    out = [r'\begin{figure}[t]', r'\centering', r'\begin{tikzpicture}',
        r'\begin{axis}[width=\columnwidth,height=4.1cm,xmode=log,log basis x=2,xlabel={$n$},ylabel={ratio},',
        r' ymin=0,ymax=19,xtick={50,100,200,400,800},xticklabels={50,100,200,400,800},',
        r' legend style={font=\scriptsize,legend columns=2,draw=none,fill=none,at={(0.5,1.02)},anchor=south},',
        r' tick label style={font=\scriptsize},label style={font=\scriptsize},legend cell align=left]']
    def series(field, denominator, style, label, rf):
        lines = [r'\addplot['+style+r',mark size=1.3pt,error bars/.cd,y dir=both,y explicit] table[x=n,y=value,y error=sd] {', 'n value sd']
        for n in ns:
            values = [float(x[field])/denominator(x) for x in groups[n,rf]]
            lines.append(f'{n} {mean(values):.7f} {stdev(values):.7f}')
        lines.extend(['};',r'\addlegendentry{'+label+'}'])
        return lines
    for field, den, style, label in [
        ('K_r',lambda x:float(x['m']),'handblue,mark=*',r'$K_r/m$'),
        ('sinks',lambda x:float(x['n']),'handred,mark=square*',r'$|\M_r|/n$')]:
        for rf, radius in [(0.5,r'$r=\bar\ell/2$'),(1.0,r'$r=\bar\ell$')]:
            out.extend(series(field,den,style+(',densely dashed' if rf==1 else ''),label+', '+radius,rf))
    out.extend([r'\end{axis}',r'\end{tikzpicture}\\[-2pt]',r'\begin{tikzpicture}',
        r'\begin{axis}[width=\columnwidth,height=4.1cm,xmode=log,log basis x=2,xlabel={$n$},ylabel={$\Rrsum/(n\rho_r^2)$},scaled y ticks=false,yticklabel style={/pgf/number format/fixed,/pgf/number format/precision=2},',
        r' ymin=0,ymax=0.065,xtick={50,100,200,400,800},xticklabels={50,100,200,400,800},',
        r' legend style={font=\scriptsize,legend columns=2,draw=none,fill=none,at={(0.5,1.02)},anchor=south},',
        r' tick label style={font=\scriptsize},label style={font=\scriptsize},legend cell align=left]'])
    for rf, label in [(0.5,r'$r=\bar\ell/2$'),(1.0,r'$r=\bar\ell$')]:
        out.extend(series('memberships',lambda x:float(x['n'])*float(x['rho'])**2,
                          'handgreen!70!black,mark=triangle*'+(',densely dashed' if rf==1 else ''),label,rf))
    out.extend([r'\end{axis}',r'\end{tikzpicture}',
        r'\caption{Random plane backbones ($n$ nodes, $m=1.6n$ links from a Delaunay triangulation, five seeds per point, $\bar\ell$ the mean link length). Points are means of the per-instance ratios; bars show sample standard deviations. Top: interacting pairs per link and maximal SRLGs per node. Bottom: output memberships relative to $n\rho_r^2$. At the smaller radius the top ratios are nearly constant; at the larger radius they increase modestly. The measurements illustrate the tested parameter regime and do not establish asymptotic linear growth.}',
        r'\label{fig:scaling}', r'\end{figure}'])
    return '\n'.join(out)+'\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--response-dir', type=Path, help='Also regenerate the response table excerpt.')
    args = parser.parse_args()
    real, raw = load('real_networks.csv'), load('synthetic_raw.csv')
    assert len(real) == 24 and len(raw) == 50
    (ROOT/'fig/table_eval.tex').write_text(backbone_table(real))
    (ROOT/'fig/plot_scaling.tex').write_text(scaling_figure(raw))
    if args.response_dir:
        (args.response_dir/'reviewer2-evaluation-table.tex').write_text(response_table(real))
    print('Generated Table 4 and Figure 5 from 24 backbone cases and 50 synthetic runs.')

if __name__ == '__main__':
    main()
