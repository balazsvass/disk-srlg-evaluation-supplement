# Reproduction record

`results/` (top level) holds the reference run reported in the paper:
Python 3.12.3, NumPy 2.4.4, SciPy 1.17.1, x86_64 Linux, single core
(`summary.json`). Its `real_networks.csv`, `lowerbound.csv` and
`synthetic_raw/*.csv` are the source of `evaluation-data/*.csv`
(`scripts/export_measurements.py --check` confirms the column subsets are
identical).

`rerun-2026-11-06/` holds a second, independent run of the curated code in
this repository on 6 November 2026 with Python 3.12.3, NumPy 2.5.4,
SciPy 1.18.1, x86_64 Linux, single core, and the full validation protocol
(200,000 random centers per backbone instance, 50,000 per synthetic
instance). All 84 cases (24 backbone, 10 lower-bound, 50 synthetic)
reproduced every non-timing column of the reference run exactly: the same
maximal families (equal to the archived lists in all 24 backbone cases), the
same K_r, |R_r|, ‖R_r‖, ρ_r and pair-coverage counts, and the same aggregate
means and standard deviations. All validation flags were true. Wall-clock
times differ between the two machines (for example 15 s versus 25 s per
enumeration for n = 800, r = l̄) and are indicative only; the paper reports
no timings.
