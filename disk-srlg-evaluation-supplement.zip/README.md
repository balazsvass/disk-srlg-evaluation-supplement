# Supplementary material: disk-SRLG enumeration evaluation

Reproducibility material for

> B. Vass, "From Geometric Backbones to Region-Disjoint Routing: Near-Optimal
> Disk-SRLG Enumeration and Deterministic Low-Polynomial Routing," submitted to
> IEEE Access, 2026.

It covers Section VI of the paper (proof-of-concept evaluation): the
floating-point disk prototype with its reproduction drivers, the 24 benchmark
inputs with checksums, the reference results for all 84 cases (24 backbone,
10 lower-bound, 50 synthetic), the retained measurements behind Table 4 and
Figure 5, the script that regenerates them, and an archive-based check of
Table 4 that needs no prototype at all.

## Layout

| path | contents |
|---|---|
| `prototype/srlgproto.py` | the enumerator (candidate witness points, closed labels with a fixed relative tolerance, inclusion-maximal filtering), the validation checks, the instance generators, and the LGF reader |
| `prototype/run_eval.py` | lower-bound family of Proposition 14 (q = 1..10) and the six networks of [9] at 50/100/200/500 km, compared with the archived lists; writes `results/real_networks.csv`, `results/lowerbound.csv`, `results/summary.json` |
| `prototype/run_synth.py` | synthetic scaling, one (n, r/l̄) group per call; writes `results/synthetic_raw/n<N>_rf<RF>.csv` |
| `prototype/make_synthetic_aggregate.py` | aggregates the synthetic runs into `results/synthetic.csv` (means and sample standard deviations over seeds) |
| `data/` | the 24 inputs `radius/<r>/<network>_srg.lgf` from the public archive of [9], their `SHA256SUMS`, and the archive's GPL-3.0 license; `fetch_data.sh` re-downloads and verifies them at the pinned commit |
| `results/` | reference results of the reported run (Python 3.12.3, NumPy 2.4.4, SciPy 1.17.1): per-case counts, validation flags, and indicative wall-clock times; `REPRODUCTION.md` records a second, independent run |
| `evaluation-data/` | the retained measurements the manuscript is generated from (column subsets of `results/`); see its `README.md` |
| `scripts/export_measurements.py` | derives `evaluation-data/*.csv` from `results/`; `--check` confirms they are identical |
| `scripts/generate_evaluation.py` | regenerates the LaTeX of Table 4 and Figure 5 into `fig/` from `evaluation-data/` |
| `scripts/check_archive.py` | recomputes n, m, ρ_r, K_r, |R_r| and ‖R_r‖ for all 24 backbone cases from the archived inputs alone and compares them with `evaluation-data/real_networks.csv` |

## Reproduce

```sh
cd prototype
python3 run_eval.py                       # 24 backbone cases + lower-bound family, ~1 min
for n in 50 100 200 400 800; do for rf in 0.5 1.0; do
  python3 run_synth.py $n $rf 0,1,2,3,4   # 50 synthetic runs, ~10 min in total
done; done
python3 make_synthetic_aggregate.py
cd ..
python3 scripts/export_measurements.py --check   # results/ -> evaluation-data/ (identical?)
python3 scripts/generate_evaluation.py           # Table 4 and Figure 5 -> fig/
python3 scripts/check_archive.py                 # Table 4 from the public inputs, no prototype needed
```

`run_eval.py --samples N` and `run_synth.py ... --samples N` reduce the
number of random disk centers in the coverage check for a quick run; the
defaults (200,000 per backbone instance, 50,000 per synthetic instance) are
the protocol reported in the paper. The prototype needs NumPy, and SciPy for
the Delaunay triangulation of the synthetic instances (`requirements.txt`);
the scripts in `scripts/` need only the standard library.

## What the prototype is and is not

The prototype follows the sink characterization (Lemma 9 of the paper), not
the plane sweep of Algorithm 1. For every interacting link pair it generates
the intersections of the two hippodromes' offset lines and endpoint circles,
adds junction and sample points of each hippodrome, evaluates the closed label
(links at distance at most r, with a tolerance of 1e-9 times the centered
extent) at each candidate, and keeps the inclusion-maximal labels with one
stored witness each. With exact predicates and generic boundaries this
candidate argument is exhaustive; the floating-point version makes no
exactness claim for inputs that are degenerate at the tolerance scale, and
does not implement the symbolic offsets of Appendix A. Its timings are not
those of Theorem 11, and no running-time comparison with earlier enumerators
is claimed.

Validation (`validate_by_sampling`): every stored witness realizes its set;
the listed sets are pairwise incomparable; the labels of random disk centers
in the bounding box are all contained in a listed set; and the pair-coverage
inequality K_r ≤ Σ C(|S|,2) of Lemma 12 holds. Random coverage is evidence,
not a completeness proof.

Not included, as stated in Section VI: arrangement face counts (shared
endpoint arcs would have to be merged) and protected-terminal enumeration (a
boundary-only candidate construction does not certify strict avoidance of the
closed protective disks). An earlier version of this code contained a
protected-terminal ablation; it was removed for that reason and nothing in
the paper depends on it.

## Benchmark inputs

The six backbone networks (16, 22, 24, 28, 39, and 79 nodes) with the archived
maximal SRLG lists for disaster radii 50, 100, 200, and 500 km are the files
`radius/{50,100,200,500}/*_srg.lgf` of the public archive of

> J. Tapolcai, L. Rónyai, B. Vass, and L. Gyimóthi, "Fast enumeration of
> regional link failures caused by disasters with limited size," IEEE/ACM
> Transactions on Networking, vol. 28, no. 6, pp. 2421-2434, 2020,

https://github.com/jtapolcai/regional-srlg at commit
`4e82386d305eee796ee7e19f5c573de0efbbea66`. Coordinates are in km. The archive
is distributed under the GNU GPL v3 (`data/LICENSE-regional-srlg-GPLv3`).
